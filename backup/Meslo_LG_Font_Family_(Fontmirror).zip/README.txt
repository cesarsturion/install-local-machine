To learn more about the font family and its license, visit https://www.fontmirror.com/meslo-lg

Copyright &copy; 2009 Apple Inc.
Copyright &copy; 2006 by Tavmjong Bah.
Copyright &copy; 2003 by Bitstream, Inc. All Rights Reserved.